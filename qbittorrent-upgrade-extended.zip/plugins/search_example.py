# Example search plugin for qBittorrent
print('Search example loaded')