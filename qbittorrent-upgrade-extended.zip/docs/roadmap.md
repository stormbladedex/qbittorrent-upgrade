## Roadmap

- [x] Base structure
- [ ] UI modernization
- [ ] Performance tuning
