## Build Instructions

1. Clone qBittorrent upstream.
2. Apply patches.
3. Build with cmake and make.
