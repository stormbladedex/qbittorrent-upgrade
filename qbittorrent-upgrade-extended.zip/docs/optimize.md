## Optimization Guide

Detailed tuning for libtorrent, cache, and network settings.