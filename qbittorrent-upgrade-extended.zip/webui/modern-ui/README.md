Modern responsive WebUI for qBittorrent.
