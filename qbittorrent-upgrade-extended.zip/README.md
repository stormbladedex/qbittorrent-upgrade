# qBittorrent Upgrade — Extended Version

Optimized fork with performance patches, WebUI improvements, and scripts.
